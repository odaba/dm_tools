 /* character_tracker.js
  * Frankie
  * version 1.6
  * 28May2013

  TODO: change gid() to $()
        change update_page() to synch()

  * 1.14
  * use new glossary filler function g_load()
  * moved a bunch of stuff from .htm script to onload function here

  * 1.6
  * update version to match char_tracker.htm
  * remove addToCharSkills()

  * 1.2
  * move gid() to general.js
  * create addToSkills()
  */

function stat_roll_btn() {
  var ddowns, i, j;
  char.roll_stats();
  gid('stat_rolls').innerHTML = char.stat_rolls;
  ddowns = gid("stat_ddowns").getElementsByTagName("select");
  for(i in ddowns) {
    if(ddowns[i].appendChild) {
      ddowns[i].innerHTML = "";
      for(j in char.stat_rolls) {
        opt = document.createElement("option");
        opt.value = j;
        opt.text = char.stat_rolls[j] + "(" + (Math.floor(char.stat_rolls[j]/2) - 5) + ") (" + ddowns[j].id.slice(0,3) + ")";
        opt.selected = (i == j) ? "selected" : "";
        ddowns[i].appendChild(opt);
      };
      ddowns[i].onchange = swap_stats;
    };
  };
}

function swap_stats() {
  var i, j, ddowns, aval, bval = this.value,
      a = this.id.slice(0,3),
      b = this.options[this.value].text.slice(-4,-1),
      bnode = gid(b + "_stat_ddown");

// check for change in status, only proceed if there is change
  if(a == b) return true;

// what used to be the value
  for(i in this.options) {
    if(a == this.options.item(i).text.slice(-4, -1)) {
      aval = this.options.item(i).value;
      break;
    };
  };

// update each ddown with new info
  ddowns = gid("stat_ddowns").getElementsByTagName("select");
  for(i in ddowns) {
    if(ddowns[i].appendChild) for(j in ddowns[i].options) {
      switch(j) {
        case aval:
        // change to b
          ddowns[i].options.item(j).text = ddowns[i].options.item(j).text.slice(0,-4) + b + ")";
          break;
        case bval:
        // change to a
          ddowns[i].options.item(j).text = ddowns[i].options.item(j).text.slice(0,-4) + a + ")";
          break;
      };
    };
  };

// change other ddown we're swapping with (.selectedIndex = #)
  bnode.selectedIndex = aval;
  return true;

}

function stat_save_btn() {
    // TODO: stat_save_btn(): make this work with new abilities object in char
  var i, ddowns = gid("stat_ddowns").getElementsByTagName("select");
  for(i in ddowns) {
    if(ddowns[i].appendChild) switch(ddowns[i].id.slice(0,3)) {
      case "str": char.abil.s[1] = char.stat_rolls[ddowns[i].value]; break;
      case "dex": char.abil.d[1] = char.stat_rolls[ddowns[i].value]; break;
      case "con": char.abil.con[1] = char.stat_rolls[ddowns[i].value]; break;
      case "int": char.abil.i[1] = char.stat_rolls[ddowns[i].value]; break;
      case "wis": char.abil.w[1] = char.stat_rolls[ddowns[i].value]; break;
      case "cha": char.abil.cha[1] = char.stat_rolls[ddowns[i].value]; break;
    };
  };
  gid("assign_stats").style.display = "none";
}

function make_tags_editable(n, e, data) {
  // TODO: make_tags_editable(): use jQuery

  var i, n_class, n_child;

  if(e) { n.setAttribute('contenteditable', 'true'); }
  else {
    n_class = n.className.split(" ");
    for(i in n_class) if(n_class[i] == 'data_editable') e = true;
  };

  if(n.nodeType == 1) { // element, can have children
    n_child = n.childNodes; // node list of children
    for(i in n_child) if(n_child[i].nodeType == 1) make_tags_editable(n_child[i], e);
  };
}

function synch() { update_page(char); }

function update_page(ch) {
  if(ch.recalc) ch.recalc('all');
  gid("char_name").innerHTML =  gid("enter_name").innerHTML =   ch.descript.generate('name');
                                gid("enter_xp").innerHTML =     ch.descript.generate('xp');
  gid("char_type").innerHTML =  gid("enter_type").innerHTML =   ch.descript.generate('type');
  gid("char_size").innerHTML =  gid("enter_size").innerHTML =   ch.descript.generate('size');
  gid("char_align").innerHTML = gid("enter_align").innerHTML =  ch.descript.generate('align');
  gid("char_level").innerHTML = gid("enter_level").innerHTML =  ch.descript.generate('level');

  gid("char_skills").innerHTML = ch.skills.generate();

  gid("char_abil").innerHTML = ch.abilities.generate();
  gid("char_hp").innerHTML = ch.combat.generate('hp');
  gid("char_fort").innerHTML = ch.defense.generate('fort');
  gid("char_refl").innerHTML = ch.defense.generate('refl');
  gid("char_will").innerHTML = ch.defense.generate('will');
  gid("char_atk").innerHTML = ch.slots.generate('atk', ch.gear);
                                gid("enter_cmb").innerHTML =    ch.combat.generate('cmb');
                                gid("enter_cmd").innerHTML =    ch.combat.generate('cmd');

  gid("char_ac").innerHTML = ch.defense.generate('ac');
}

window.onload = function () {
  // Load needed glossary items
  g_load(['skills', 'abilities', 'gear']);
  char.addInfo(char_default);

  // Massage DOM on page
  make_tags_editable(gid("data_entry"), false, char);
  make_tags_editable(gid("data_who"), false, char);
  make_tags_editable(gid("data_desc"), false, char);
};

var char = new Char(),
    char_default = {
      name: "Ragnar", xp: 1300,
      level: "Rogue 3",
      align: "Chaotic",
      size: "Med",
      type: "humanoid(Human)",
      stat_rolls: [18, 16, 16, 15, 13, 10],
      abilities: { str: 10, dex: 18, con: 15, 'int': 16, wis: 13, cha: 16 },
      skills: { // [shown, ranks]
        bluff:      [true,6],
        dDevice:    [true,2],
        disguise:   [true,6],
        dScript:    [false,1],
        gInfo:      [false,6],
        hAnimal:    [false,1],
        hide:       [true,6],
        kDungeon:   [false,1],
        kLocal:     [false,1],
        kNobility:  [false,1],
        listen:     [true,6],
        mSilent:    [true,6],
        oLock:      [false,1],
        proSailor:  [false,1],
        proArtist:  [true,1],
        search:     [false,6],
        sMotive:    [true,6],
        SoHand:     [false,1],
        spot:       [true,6],
        tumble:     [false,6],
        UMD:        [false,3]
      },
      hp_rolls: [6, 3, 4],
      bab: 1,
      base_saves: { f:1, r:3, w:1 },
      gear: [ // quantity, name, where, properties
        [1, "morningstar",    "sheath",   {type: "weapon"}],
        [1, "dagger",         "sheath",   {type: "weapon"}],
        [4, "dagger",         "hidden",   {type: "weapon"}],
        [1, "Rapier",         "weapon1",  {type: "weapon", mwk: true}],
        [1, "light crossbow", "sheath",   {type: "weapon"}],
        [20, "crossbow bolt", "sheath",   {type: "ammunition"}],
        [1, "Chain shirt",    "body",     {type: "armor", mwk: true, category: "light", bonus: 4, maxDex: 4, check: 1, arcaneFailure: 20}],
        [1, "Buckler",        "shield",   {type: "shield", mwk: true, bonus: 1, maxDex: "n", check: 0, arcaneFailure: 5}],
        [1, "backpack",       "worn",     {type: "container"}],
        [1, "adventures kit", "backpack", {}],
        [1, "thieves tools",  "backpack", {}],
        [1, "coinpurse",      "backpack", {type: "container"}],
        [6, "gold",           "coinpurse", {}],
        [1, "guard dog",      "", {}]
      ]
    };
